 <!-----------------author profile start-------------------------->
    <div class="row mt-85 text-center"
        style="border-radius: 25px;border: 2px solid #ccc;padding: 20px;">
        <div class="col-sm-4 mx-auto">
            <!--<ul class="post-meta-item mr-15">-->
            <!--<li>-->
            <img src="https://gtechwebsite.s3.us-east-1.amazonaws.com/prod/images/wp-content/uploads/2023/blog/gopi_sir.png"
                style="margin-right:20px;">
        </div>
        <div class="col-sm-8 mx-auto">
            <h4>The Author</h4>
            <h3>Gopinath Murugaiyan</h3>
            <p>Managing Director</p>
            <div class="social-icons">
                <a href="https://www.facebook.com/NMGopinath"> <i
                        class="fab fa-facebook-f"></i></a>
                <a href="https://www.linkedin.com/in/nmgopinath/"><i
                        class="fab fa-linkedin-in"></i></a>
                <a href="https://www.instagram.com/nmgopinath/"><i
                        class="fab fa-instagram"></i></a>
            </div>
        </div>
    </div>
<!-----------------author profile startend-------------------------->