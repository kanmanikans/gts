<div class="blog-sidebar mt-35 rmy-100">
                            <!-- <div class="widget widget-search wow fadeInUp delay-0-2s">
                                <form action="#">
                                    <input type="text" placeholder="Search" class="searchbox" required>
                                    <button type="submit" class="searchbutton fa fa-search"></button>
                                </form>
                            </div> -->
                            <!--<div class="widget widget-category wow fadeInUp delay-0-2s">-->
                            <!--    <h3 class="widget-title">Book Appointment</h3>-->
                            <!--    <ul class="list-style-two">-->
                            <!--        <li><a href="#">Business Strategy</a> <span>(20)</span></li>-->
                            <!--        <li><a href="#">Investment Planning</a> <span>(05)</span></li>-->
                            <!--        <li><a href="#">Financial Investment</a> <span>(03)</span></li>-->
                            <!--        <li><a href="#">Banking & Insurance</a> <span>(30)</span></li>-->
                            <!--        <li><a href="#">Free Consulting</a> <span>(07)</span></li>-->
                            <!--        <li><a href="#">Meet Our Team</a> <span>(09)</span></li>-->
                            <!--    </ul>-->
                            <!--</div>-->
                            <div class="widget widget-category wow fadeInUp delay-0-2s">
                                <h3 class="widget-title">Category</h3>
                                <ul class="list-style-two">
                                    <li><a href="https://gtechwebsolutions.com/blog/general/">General</a> <span>(03)</span></li>
                                    <li><a href="https://gtechwebsolutions.com/blog/ios/">ios</a> <span>(06)</span></li>
                                    <li><a href="https://gtechwebsolutions.com/blog/react-native/">React Naive</a> <span>(05)</span></li>
                                    <li><a href="https://gtechwebsolutions.com/blog/mobile-app-development/">Mobile App Development</a> <span>(06)</span></li>
                                    <li><a href="https://gtechwebsolutions.com/blog/mobile-app-marketing/">Mobile App Marketing</a> <span>(02)</span></li>
                                    <li><a href="https://gtechwebsolutions.com/blog/ecommerce-mobile-app/">Ecommerce Mobile App</a> <span>(02)</span></li>
                                    <li><a href="https://gtechwebsolutions.com/blog/android/">Android</a> <span>(06)</span></li>
                                    <li><a href="https://gtechwebsolutions.com/blog/digital-marketing/">Digital marketing</a> <span>(09)</span></li>
                                    <li><a href="https://gtechwebsolutions.com/blog/seo/">SEO</a> <span>(09)</span></li>
                                    <li><a href="https://gtechwebsolutions.com/blog/ppc/">PPC</a> <span>(02)</span></li>
                                    <li><a href="https://gtechwebsolutions.com/blog/food/">Food</a> <span>(13)</span></li>
                                    <li><a href="https://gtechwebsolutions.com/blog/grocery/">Grocery</a> <span>(05)</span></li>
                                    <li><a href="https://gtechwebsolutions.com/blog/laundry/">Laundry</a> <span>(03)</span></li>
                                    <li><a href="https://gtechwebsolutions.com/blog/meat/">Meat</a> <span>(03)</span></li>
                                     <li><a href="https://gtechwebsolutions.com/blog/cake/">Cake</a> <span>(02)</span></li>
                                      <li><a href="https://gtechwebsolutions.com/blog/wordpress/">Wordpress</a> <span>(01)</span></li>
                                      <li><a href="https://gtechwebsolutions.com/blog/beauty/">Beauty</a> <span>(01)</span></li>
                                      <li><a href="https://gtechwebsolutions.com/blog/pickup/">Pickup</a> <span>(02)</span></li>
                                       <li><a href="https://gtechwebsolutions.com/blog/medicine/">Medicine</a> <span>(02)</span></li>
                                        <li><a href="https://gtechwebsolutions.com/blog/taxi/">Taxi</a> <span>(02)</span></li>
                                        <li><a href="https://gtechwebsolutions.com/blog/cloud-kitchen/">Cloud Kitchen</a> <span>(01)</span></li>
                                        <li><a href="https://gtechwebsolutions.com/blog/web-development/">Web Development</a> <span>(02)</span></li>
                                    <!--<li><a href="#"></a> <span>(09)</span></li>-->
                                </ul>
                            </div>
                            <div class="widget widget-recent-post wow fadeInUp delay-0-4s">
                                <h3 class="widget-title">Recent Blog</h3>
                                <div class="widget-news-wrap">
                                    <div class="widget-news-item">
                                        <img src="https://gtechwebsite.s3.us-east-1.amazonaws.com/prod/images/wp-content/uploads/2023/blog/how-to-develop-a-top-notch-swiggy-zomato-talabat-clone-app-768x356-1-1-1-64ec650175f6b.webp" alt="News">
                                        <div class="widget-news-content">
                                            <h5><a href="https://gtechwebsolutions.com/blog/advantages-of-restaurant-food-delivery-apps/">Benefits Of Having Online Food Delivery App For Restaurant Business</a>
                                            </h5>
                                            <span class="date"><a href="#">22/08/2023</a></span>
                                        </div>
                                    </div>
                                    <div class="widget-news-item">
                                        <img src="https://dbolm29vzchgq.cloudfront.net/prod/images/wp-content/uploads/2022/08/22154204/cost-to-develop-laundry-app-1-768x278-1-1.png" alt="News">
                                        <div class="widget-news-content">
                                            <h5><a href="https://gtechwebsolutions.com/blog/laundry-app-development-cost/">Get a crystal-clear idea of laundry delivery app development…</a>
                                            </h5>
                                            <span class="date"><a href="#">15 Dec 2023</a></span>
                                        </div>
                                    </div>
                                    <div class="widget-news-item">
                                        <img src="https://dbolm29vzchgq.cloudfront.net/prod/images/wp-content/uploads/2023/03/01134333/imgpsh_fullsize_anim.png" alt="News">
                                        <div class="widget-news-content">
                                            <h5><a href="https://gtechwebsolutions.com/blog/get-a-clear-idea-about-the-cost-to-build-a-cloud-kitchen-app/">Cost To Build A Cloud Kitchen App</a></h5>
                                            <span class="date"><a href="#">15 Dec 2023</a></span>
                                        </div>
                                    </div>
                                    <div class="widget-news-item">
                                        <img src="https://gtechwebsite.s3.us-east-1.amazonaws.com/prod/images/wp-content/uploads/2023/blog/avail-it-augmentation-1-1-64ec64e702ee4.webp" alt="News">
                                        <div class="widget-news-content">
                                            <h5><a href="https://gtechwebsolutions.com/blog/it-staff-augmentation-services-benefit/">Need IT staff augmentation services? Avail it from the…</a></h5>
                                            <span class="date"><a href="#">15 Dec 2023</a></span>
                                        </div>
                                    </div>
                                    <div class="widget-news-item">
                                        <img src="https://gtechwebsite.s3.us-east-1.amazonaws.com/prod/images/wp-content/uploads/2023/blog/local-seo-pricing-1536x555-1-64ec64dfe8413.webp" alt="News">
                                        <div class="widget-news-content">
                                            <h5><a href="https://gtechwebsolutions.com/blog/affordable-local-seo-packages/">Get an unclouded idea on local SEO services pricing…</a></h5>
                                            <span class="date"><a href="#">15 Dec 2023</a></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!--<div class="widget widget-tag-cloud wow fadeInUp delay-0-2s">-->
                            <!--    <h3 class="widget-title">Category</h3>-->
                            <!--    <div class="tags">-->
                            <!--        <a href="#">Cleaning</a>-->
                            <!--        <a href="#">Business</a>-->
                            <!--        <a href="#">Booking</a>-->
                            <!--        <a href="#">car</a>-->
                            <!--        <a href="#">House</a>-->
                            <!--        <a href="#">Apartment</a>-->
                            <!--        <a href="#">Washing</a>-->
                            <!--        <a href="#">Agency</a>-->
                            <!--        <a href="#">Listing</a>-->
                            <!--    </div>-->
                            <!--</div>-->
                            <div class="widget widget-call-action wow fadeInUp delay-0-2s">
                                <div class="call-action-widget">
                                    <h2>Work Together</h2>
                                    <p>Over 12+ years of EXPERIENCE, we’ve sucessfully deliver more than 520 projects all around the world.</p>
                                    <h2><strong>We can help you with</strong></h2>
                                    <ul class="custom-list" style="padding-bottom:20px;">
                                        <li><a href="https://gtechwebsolutions.com/service/mobile-app-development/" style="color:#ffffff;">Mobile App Development</a> </li>
                                        <li><a href="https://gtechwebsolutions.com/service/web-development/" style="color:#ffffff;">Website Development</a></li>
                                        <li><a href="https://gtechwebsolutions.com/service/digital-marketing/" style="color:#ffffff;">Digital Marketing</a></li>
                                       
                                            </ul>
                                             <a class="theme-btn style-five btn-circle" href="https://gtechwebsolutions.com/contact-us/">Contact Now <i
                                            class="fas fa-angle-double-right" ></i></a>
                                </div>
                            </div>
                        </div>